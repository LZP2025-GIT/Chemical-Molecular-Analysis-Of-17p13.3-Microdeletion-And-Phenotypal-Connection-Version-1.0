# Provenance Notes

This repository was assembled from the frozen project documents available on 2026-10-01.

## Preservation rules

- GRCh37/hg19 chr17:1,411,408-1,841,103 remains the controlling structural reference.
- GRCh38 must not silently replace or be mixed with the fixed CNV coordinates.
- Frozen conclusions remain frozen unless changed through a documented erratum or new version.
- No missing raw data, code, breakpoint sequence, experiment, statistical result, or Phase 5 narrative was invented during repository packaging.

## Phase 5 limitation

The archive contained the frozen Phase 5 casual-reader summary and detailed analytical protocol, but a separate standalone full narrative Phase 5 master-report file was not available as a reusable local artifact. The canonical integrated project PDF remains the authoritative packaged representation of the Phase 5 content available in this record.
