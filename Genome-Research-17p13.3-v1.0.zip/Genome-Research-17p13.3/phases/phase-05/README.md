# Phase 5 — Frozen Record and Archival Status

Phase 5 examined deterministic evidence integration, in-silico gap resolution, mechanistic modeling, reproducibility, sensitivity analysis, and methodological failure modes for the 17p13.3 deletion project.

## Archival note

The project archive available when this repository was assembled contained the frozen Phase 5 casual-reader summary and the detailed Phase 5 analysis protocol, but not a separate standalone full narrative Phase 5 master-report file comparable to the Phase 4 frozen master report. This repository does **not** reconstruct missing prose or invent analyses.

The canonical integrated record of Phase 5 is preserved in the full project release under `release/Genome_Research_Complete_Project_APA7_v1_0.pdf`. The plain-language findings are summarized below and in the repository-level five-page summary.

## Frozen Phase 5 findings

- The leading interpretation remained a distributed visual-neural functional-reserve model rather than a single-gene photosensitivity mechanism.
- Stronger candidate outcome domains were retinal/RPE reserve, neural development/network organization, and stress-dependent vulnerability.
- Seizure susceptibility or epileptogenesis had some supporting evidence, but the exact heterozygous deletion was not shown to cause epilepsy or photic seizures.
- The direct physiological chain from retina through thalamus and visual cortex to photoparoxysmal response remained unmeasured for the exact CNV.
- Complete knockout evidence was not treated as equivalent to heterozygous deletion evidence.
- Missing evidence was kept distinct from evidence of absence.
- The standardized simulation suite used 20,000 repetitions per scenario/cell where applicable, totaling approximately 1.88 million primary stochastic draws/resamples.
- Simulations showed that small heterozygous effects can be missed with too few independent biological replicates, that repeated cells from a single clone do not replace independent replication, that uncorrected frequency scans can generate false positives, and that small datasets can incorrectly make a distributed mechanism appear single-gene driven.

## Phase 5 analytical framework

The protocol defined a causal chain from genomic disruption through dosage, molecular perturbation, spatiotemporal opportunity, retinal/neural consequences, cortical/network transformation, and photic phenotype relevance. It required competing models, random-interval null testing, sensitivity analyses, leave-one-locus-out analyses, explicit counterevidence, and strict separation of observed, inferred, contradicted, unresolved, and experimentally inaccessible evidence.

For the frozen record, see the complete project PDF in `release/`.
