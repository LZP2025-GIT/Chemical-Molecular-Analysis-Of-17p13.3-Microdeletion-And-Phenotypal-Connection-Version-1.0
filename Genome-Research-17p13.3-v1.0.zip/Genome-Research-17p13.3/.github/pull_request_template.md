## Purpose

Describe the change.

## Scientific record impact

- [ ] Formatting/documentation only
- [ ] Reproducibility improvement
- [ ] Erratum/correction
- [ ] New evidence
- [ ] Reinterpretation
- [ ] New-version candidate

## Prior frozen conclusion affected

State the prior conclusion exactly or write "None."

## Evidence and provenance

Provide sources, identifiers, model/tissue/genotype state, versions, parameters, and limitations.

## Contradictory/null evidence considered

Describe relevant counterevidence and whether the change alters the evidence boundary.
