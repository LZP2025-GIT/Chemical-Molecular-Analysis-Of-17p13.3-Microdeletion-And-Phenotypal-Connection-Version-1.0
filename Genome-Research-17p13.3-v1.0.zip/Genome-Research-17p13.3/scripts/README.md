# Analysis Scripts

No complete executable analysis-code archive was available in the frozen project materials when Version 1.0 of this repository was packaged. This directory is intentionally not populated with reconstructed or speculative code.

Future reproducibility work should add scripts with:

- source/accession provenance;
- genome build and annotation version;
- dependency versions;
- random seeds;
- parameters and filters;
- input/output checksums;
- explicit treatment of missing data;
- independent-replicate definitions;
- multiple-testing procedures where applicable.
